### jUnit Sample Demo 

This package includes sample java code integrate with JUnit testing framework.

This package can be compiled with Maven / Ant

JUnit Sample demo integrate with qTest Automation Host

### How to use sample package to integrate with qTest Automation Host
- First, setup qTest Automation Host. And install JUnit for Java framework in qTest Automation Host.
- Download JUnit sample package and unzip in your directory (eg: D:\Demo\junit-sample).
- Open command line at directory D:\Demo\junit-sample and execute command: *mvn clean compile package test*
- Set up new agent with configure Agent below:

### Agent Configuration
![Agent Configuration](/agent-configuration.png?raw=true)
